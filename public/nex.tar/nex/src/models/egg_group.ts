export interface EggGroup {
  id: number;
  name: string;
}
