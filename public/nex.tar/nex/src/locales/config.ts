export const defaultLocale = 'en'
